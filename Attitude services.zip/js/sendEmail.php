<style>
.sucess{
color:#088A08;
}
.error{
color:red;
}
</style>

<?php
function filterInput($data)
{
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}
ini_set('display_errors', 1);
$senderEmail = filterInput($_POST['semail']);
$recipientEmail = filterInput($_POST['remail']);
$message1 = filterInput($_POST['Message']);
$subject = filterInput($_POST['Subject']);
 
echo $senderEmail.$recipientEmail.$message.$subject;

$uploadDir = "uploadResumes/";


 $result = move_uploaded_file($_FILES["file"]["tmp_name"],
       "uploadResumes/" . $_FILES["file"]["name"]);
echo $result;

echo "Upload complete.<br>";

    $body = "email in html form";

    // email fields: to, from, subject, and so on
    $to = 'vasanth@ticketgoose.com';
    $from = $recipientEmail;
    $message = html_entity_decode($message1);
    $headers = "From: $from\r\n";
	$subject = "Resume - $from\r\n";
    // boundary
    $semi_rand = md5(time());
    $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
    $upload_name= "uploadResumes/" . $_FILES["file"]["name"];
    $upload_type="uploadResumes/" .$_FILES["file"]["type"];
    $upload_size="uploadResumes/" .$_FILES["file"]["size"];
    $upload_temp="uploadResumes/" .$_FILES["file"]["tmp_name"];
echo  $upload_name;
echo  $upload_type;
   $file_size = filesize($upload_name);
    $fp = fopen($upload_name, "rb");
    $file = fread($fp, $file_size);
 
    $file = chunk_split(base64_encode($file));
    $num = md5(time());
 
        //Normal headers
 
       $headers  .= "MIME-Version: 1.0\r\n";
       $headers  .= "Content-Type: multipart/mixed; ";
       $headers  .= "boundary=".$num."\r\n";
       $headers  .= "--$num\r\n";
 
		 $headers .= "Content-Type: text/html; charset=iso-8859-1\r\n";
       $headers .= "Content-Transfer-Encoding: 8bit\r\n";
       $headers .= "".$message."\n";
       $headers .= "--".$num."\n";
 
        // Attachment headers
 
    $headers  .= "Content-Type:".$upload_type." ";
       $headers  .= "name=\"".$upload_name."\"r\n";
       $headers  .= "Content-Transfer-Encoding: base64\r\n";
       $headers  .= "Content-Disposition: attachment; ";
       $headers  .= "filename=\"".$upload_name."\"\r\n\n";
       $headers  .= "".$file."\r\n";
       $headers  .= "--".$num."--";
	   
		 fclose($fp);
    // send

    $ok = @mail($to, $subject, $message, $headers);
    if ($ok) {
        echo "<p>mail sent to $to!</p>";
    } else {
        echo "<p>mail could not be sent!</p>";
    }
$Message = urlencode("MailSend...... ");
die;
?>